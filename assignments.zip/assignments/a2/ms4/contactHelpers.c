/* -------------------------------------------
Name:Shubham Patel           
Student number:115016172 
Email:srpatel33@myseneca.ca          
Section:s        
Date:20-dec-2017           
----------------------------------------------
Assignment: 2
Milestone:  4
---------------------------------------------- */

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

// This source file needs to "know about" the SYSTEM string library functions.
// HINT: The library name is string.h.
//       #include the string.h header file on the next line:

#include <string.h>

// ----------------------------------------------------------
// Include your contactHelpers header file on the next line:

#include "contactHelpers.h"

// ----------------------------------------------------------
// define MAXCONTACTS for sizing contacts array (5):

#define MAXCONTACTS 5

//------------------------------------------------------
// Function Definitions
//------------------------------------------------------

// +-------------------------------------------------+
// | NOTE:  Copy/Paste your Assignment-2 Milestone-3 |
// |        function definitions below...            |
// +-------------------------------------------------+

// clearKeyboard:  Empty function definition 
void clearKeyboard(void)
{
	while (getchar() != '\n')   ; // empty execution code block on purpose
}

// pause: Empty function definition goes here:

void pause(void)
{
	printf("(Press Enter to Continue)");
	clearKeyboard();
}

// getInt: Empty function definition goes here:

int getInt(void)
{
	char NL = 'x';
	int Value;
	while (NL != '\n')
	{
		scanf("%d%c", &Value, &NL);
		if (NL != '\n')
		{
			clearKeyboard();
			printf("*** INVALID INTEGER *** <Please enter an integer>: ");
		}
	}
	return Value;
}

// getIntInRange: Empty function definition goes here:

int getIntInRange(int low, int high)
{
	int number;
	do{
		number = getInt();
		if ( (number < low) || (number > high))
		{
			printf("*** OUT OF RANGE *** <Enter a number between %d and %d>: ", low, high);
		}
	}while ( (number < low) || (number > high));

	return number;
}

// yes: Empty function definition goes here:

int yes(void)
{
	char NL = 'x';
	char option;
	int Value;
	while (NL != '\n' || ((option != 'Y') && ((option != 'y') && (option != 'N') && (option != 'n'))))
	{
		scanf(" %c%c", &option, &NL);
		if (NL != '\n' || ((option != 'Y') && ((option != 'y') && (option != 'N') && (option != 'n'))))
		{
			clearKeyboard();	
			printf("*** INVALID ENTRY *** <Only (Y)es or (N)o are acceptable>: ");
		}

	}
	if ((option == 'Y') || (option == 'y'))
	{       
		Value = 1;
	}
	else
	{
		Value = 0;
	}
	
	return Value;
}

// menu: Empty function definition goes here:

int menu(void)
{
	int option;
	printf("Contact Management System");
	printf("\n-------------------------");
	printf("\n1. Display contacts");
	printf("\n2. Add a contact");
	printf("\n3. Update a contact");
	printf("\n4. Delete a contact");
	printf("\n5. Search contacts by cell phone number");
	printf("\n6. Sort contacts by cell phone number");
	printf("\n0. Exit");
	printf("\n\nSelect an option:> ");
	option = getIntInRange(0, 6);

	return option;
}

// ContactManagerSystem: Empty function definition goes here:

void ContactManagerSystem(void)
{
	int value = 1;
	int option;
	struct Contact contacts[MAXCONTACTS] = { { { "Rick", {'\0'}, "Grimes" }, { 11, "Trailer Park", 0, "A7A 2J2", "King City" }, { "4161112222", "4162223333", "4163334444" } }, 
						{ { "Maggie", "R.", "Greene" }, { 55, "Hightop House", 0, "A9A 3K3", "Bolton" }, { "9051112222", "9052223333", "9053334444" } }, 
						{ { "Morgan", "A.", "Jones" }, {77, "Cottage Lane", 0, "C7C 9Q9", "Peterborough" }, { "7051112222", "7052223333", "7053334444" } }, 
						{ { "Sasha", {'\0'}, "Williams" }, { 55, "Hightop House", 0, "A9A 3K3", "Bolton" }, { "9052223333", "9052223333", "9054445555" } }, }; 

	while (value != 0)
	{
		value = menu();
		switch (value)
		{
			case 0:
				printf("\nExit the program? (Y)es/(N)o: ");
				option = yes();
				if (option == 0)
				{
					value = 1;
				}
				else
				{
					printf("\nContact Management System: terminated");
				}
				break;
			case 1:
				printf("\n");
				displayContacts(contacts, MAXCONTACTS);
				pause();
				break;
			case 2:
				printf("\n");
				addContact(contacts, MAXCONTACTS);
				pause();
				break;
			case 3:
				printf("\n");
				updateContact(contacts, MAXCONTACTS);
				pause();
				break;
			case 4:
				printf("\n");
				deleteContact(contacts, MAXCONTACTS);
				pause();
				break;
			case 5:
				printf("\n");
				searchContacts(contacts, MAXCONTACTS);
				pause();
				break;
			case 6:
				printf("\n");
				sortContacts(contacts, MAXCONTACTS);
				pause();
				break;
		}
		printf("\n");
	}       
}


// +-------------------------------------------------+
// | NOTE:  Copy/Paste your Assignment-2 Milestone-3 |
// |        empty function definitions below...      |
// +-------------------------------------------------+

// Generic function to get a ten-digit phone number (ensures 10 chars entered)
void getTenDigitPhone(char telNum[])
{
    int needInput = 1;
	//int i;
	
	
    while (needInput == 1) {
	scanf("%10s", telNum);
	clearKeyboard();

	// (String Length Function: validate entry of 10 characters)
	if (strlen(telNum) == 10)
	    needInput = 0;
		
		
		
	else
	    printf("Enter a 10-digit phone number: ");
    }
}

// findContactIndex:
int findContactIndex(const struct Contact contacts[], int size, const char cellNum[])
{
	int find = -1;
	int i;
	
	for(i=0;i<size;i++)
	{
		if(strcmp((contacts[i].numbers.cell), cellNum) == 0)
		{
			find = i;
			i = size;
		}
	}
	
    return find;
}


// displayContactHeader
// Put empty function definition below:

void displayContactHeader(void)
{
	printf("+-----------------------------------------------------------------------------+\n");
	printf("|                              Contacts Listing                               |\n");
	printf("+-----------------------------------------------------------------------------+\n");
}

// displayContactFooter
// Put empty function definition below:

void displayContactFooter(int totalcontacts)
{
	printf("+-----------------------------------------------------------------------------+\n");
	printf("Total contacts: %d\n\n", totalcontacts);
}

// displayContact:
// Put empty function definition below:

//not done, does not test for unfilled structs
void displayContact(const struct Contact contact)
{
	//printf(" %s %s %s\n", contact.name.firstName, contact.name.middleInitial, contact.name.lastName);
	printf(" %s", contact.name.firstName);
	if(strlen(contact.name.middleInitial) > 0){

	//if(contact.name.middleInitial > 0){
		printf(" %s", contact.name.middleInitial);
	}
	printf(" %s\n", contact.name.lastName);
	printf("    C: %-10s   H: %-10s   B: %-10s\n", contact.numbers.cell, contact.numbers.home, contact.numbers.business);
	printf("       %d %s, ", contact.address.streetNumber, contact.address.street);
	if (contact.address.apartmentNumber > 0)
	{
		printf("Apt# %d, ", contact.address.apartmentNumber);
	}
	printf("%s, %s\n", contact.address.city, contact.address.postalCode);
	//clearKeyboard();
}

// displayContacts:
// Put empty function definition below:

void displayContacts(const struct Contact contacts[], int size)
{
	int i;
	displayContactHeader();
	int validcontact = 0;
	for (i = 0; i < size; i++)
	{
		if (strlen(contacts[i].numbers.cell) == 10)
		{
			displayContact(contacts[i]);
			validcontact++;
		}
	}
	displayContactFooter(validcontact);
}

// searchContacts:
// Put empty function definition below:

void searchContacts(const struct Contact contacts[], int size)
{
	char queryphonenumber[11];
 
	int search;
	printf("Enter the cell number for the contact: ");

	getTenDigitPhone(queryphonenumber);
	search = findContactIndex(contacts, size, queryphonenumber);
	if (search == -1)
	{
		printf("*** Contact NOT FOUND ***");
	}
	else
	{
		printf("\n");
		displayContact(contacts[search]);
		printf("\n");
	}
	
}

// addContact:
// Put empty function definition below:

void addContact(struct Contact contacts[], int size)
{
	int validcontact = 0;
	int i;
	int index;
	for (i = 0; i < size; i++)
	{
		if (strlen(contacts[i].numbers.cell) != 10)
		{
			validcontact++;
			index = i;
			i = size;
		}
	}
	if (validcontact == 0)
	{
		printf("*** ERROR: The contact list is full! ***\n");
	}
	else
	{
		getContact(&(contacts[index]));
		printf("--- New contact added! ---\n");
	}
}

// updateContact:
// Put empty function definition below:

void updateContact(struct Contact *contacts, int size)
{
	int find;
	char telNum[11];
	printf("Enter the cell number for the contact: ");
	getTenDigitPhone(telNum);
	find = findContactIndex(contacts, size, telNum);
	if ( find == -1)
	{
		printf("*** Contact NOT FOUND ***\n");
	}
	else
	{
		printf("\nContact found:\n");
		displayContact(contacts[find]);
		printf("\nDo you want to update the name? (y or n): ");
		
		if (yes() == 1)
		{
			getName(&(contacts[find].name));
		}
		printf("Do you want to update the address? (y or n): ");
	         clearKeyboard();
		if (yes() == 1)
		{
		        
			getAddress(&(contacts[find].address));
		}
	
		printf("Do you want to update the numbers? (y or n): ");
			  
		if (yes() == 1)
		{
			
			getNumbers((&contacts[find].numbers));
		
		
		}
		printf("--- Contact Updated! ---\n");
	}
}

// deleteContact:
// Put empty function definition below:

void deleteContact(struct Contact contacts[], int size)
{
	char queryNum[11];
	int find;
	printf("Enter the cell number for the contact: ");
	getTenDigitPhone(queryNum);
	find = findContactIndex(contacts, size, queryNum);
	if (find == -1)
	{
		printf("*** Contact NOT FOUND ***");
	}
	else
	{
		printf("\nContact found:\n");
		displayContact(contacts[find]);
		printf("\nCONFIRM: Delete this contact? (y or n): ");
		if (yes() == 1)
		{
			strcpy(contacts[find].numbers.cell, "");
			printf("--- Contact deleted! ---\n");
		}
	}

}

// sortContacts:
// Put empty function definition below:

void sortContacts(struct Contact contacts[], int size)
{
	printf("<<< Feature to sort is unavailable >>>\n");
}

