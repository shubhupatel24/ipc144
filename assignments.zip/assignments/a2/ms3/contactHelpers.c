/* -------------------------------------------
Name:
Student number:
Email:
Section:
Date:
----------------------------------------------
Assignment: 2
Milestone:  3
---------------------------------------------- */

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

// This source file needs to "know about" the SYSTEM string library functions.
// HINT: The library name is string.h.
//       #include the string.h header file on the next line:
#include <string.h>


// ----------------------------------------------------------
// Include your contactHelpers header file on the next line:
#include "contactHelpers.h"


//------------------------------------------------------
// Function Definitions
//------------------------------------------------------

// +-------------------------------------------------+
// | NOTE:  Copy/Paste your Assignment-2 Milestone-2 |
// |        function definitions below...            |
// +-------------------------------------------------+

// clearKeyboard:
void clearKeyboard(void)
{
    while (getchar() != '\n')   ; // empty execution code block on purpose
}


// pause:
void pause(void)
{
	printf("(Press Enter to continue)");
       clearKeyboard();
}


// getInt:
int getInt(void)
{
	char NL = 'x';
	int Value;
	while(NL!= '\n'){
		scanf("%d%c", &Value, &NL);

	    if(NL != '\n'){
		clearKeyboard();
		printf("*** INVALID INTEGER *** <Please enter an integer> ");
	     }
	}
       return Value;
}


// getIntInRange:
int getIntInRange(int low, int high)
{
	int number;
	//do{
      while( (number < low) || (number > high)){
		number = getInt();
		if( (number < low) || (number > high))
		{
		printf("*** OUT OF RANGE *** <Enter a number between %d and %d>: ", low, high);
		}
	}//while( (number < high) || (number > low));
	return number;
}


// yes:
int yes(void)
{
	char NL = 'x';
	char option;
	int Value;
	while ( NL != '\n' || (( option != 'Y') && ( option != 'y' ) && ( option != 'N' ) && ( option != 'n')))
	{
		scanf("%c%c", &option, &NL);
		if((NL != '\n') || ((option != 'Y') && (option != 'y') && (option != 'N') && (option != 'n'))){
			clearKeyboard();
			printf("*** INVALID ENTRY *** <Only (Y)es or (N)o are acceptable>: ");
		}
	}
		if((option == 'Y') || (option == 'y'))
		{
		  Value = 1;
		}
		else
		{
		  Value = 0;
		}
	return Value;
}


// menu:
int menu(void)
{
	int option;
	printf("Contact Management System");
	printf("\n-------------------------");
	printf("\n1. Display contacts");
	printf("\n2. Add a contact");
	printf("\n3. Update a contact");
	printf("\n4. Delete a contact");
	printf("\n5. Search contacts by cell phone number");
	printf("\n6. Sort contacts by cell phone number");
	printf("\n0. Exit");
	printf("\n\nSelect an option:> ");
	option = getIntInRange(0, 6);
	return option;
}


// ContactManagerSystem:
void ContactManagerSystem(void)
{
    int Value = 1;
    int option;
    while(Value != 0){
	    Value = menu();
	    switch (Value)
	    {
		    case 0:
		  printf("\nExit the program? (Y)es/(N)o: ");
		  option = yes();
		  if(option == 0){
			  Value = 1;
		  }
		  else{
			  printf("\nContact Management System: terminated");
		  }
		    break;
		    case 1:
		   printf("\n<<< Feature 1 is unavailable >>>\n\n");
		   pause();
		    break;
		    case 2:
		    printf("\n<<< Feature 2 is unavailable >>>\n\n");
		    pause();
		    break;
		    case 3:
		    printf("\n<<< Feature 3 is unavailable >>>\n\n");
		    pause();
		    break;
		    case 4:
		    printf("\n<<< Feature 4 is unavailable >>>\n\n");
		    pause();
		    break;
		    case 5:
		    printf("\n<<< Feature 5 is unavailable >>>\n\n");
		    pause();
		    break;
		    case 6:
		    printf("\n<<< Feature 6 is unavailable >>>\n\n");
		    pause();
		    break;
	    }
	    printf("\n");
   }
}


// +-------------------------------------------------+
// | ====== Assignment 2 | Milestone 3 =======       |
// +-------------------------------------------------+
// | Put empty function definitions below...         |
// +-------------------------------------------------+

// Generic function to get a ten-digit phone number (ensures 10 chars entered)
void getTenDigitPhone(char telNum[])
{
    int needInput = 1;

    while (needInput == 1) {
	scanf("%10s", telNum);
	clearKeyboard();

	// (String Length Function: validate entry of 10 characters)
	if (strlen(telNum) == 10)
	    needInput = 0;
	else
	    printf("Enter a 10-digit phone number: ");
    }
}

// findContactIndex:
int findContactIndex(const struct Contact contacts[], int size, const char cellNum[])
{
    return -1;
}


// displayContactHeader
// Put empty function definition below:
void displayContactHeader(void)
{

}

// displayContactFooter
// Put empty function definition below:
void displayContactFooter(void)
{

}

// displayContact:
// Put empty function definition below:
void displayContact(void)
{

}

// displayContacts:
// Put empty function definition below:
void displayContacts(void)
{

}

// searchContacts:
// Put empty function definition below:
void searchContacts(void)
{

}

// addContact:
// Put empty function definition below:
void addContact(void)
{

}

// updateContact:
// Put empty function definition below:
void updateContact(void)
{

}

// deleteContact:
// Put empty function definition below:
void deleteContact(void)
{

}

// sortContacts:
// Put empty function definition below:
void sortContacts(void)
{

}
