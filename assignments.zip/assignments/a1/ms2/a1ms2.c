/* -------------------------------------------
Name:Shubham patel
Student number:115016172
Email:srpatel33@myseneca.ca
Section:s
Date:29-Nov-2017
----------------------------------------------
Assignment: 1
Milestone:  2
---------------------------------------------- */

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

// This source file needs to "know about" the structures you declared
// in the header file before referring to those new types:
// HINT: put the header file name in double quotes so the compiler knows
//       to look for it in the same directory/folder as this source file
// #include your contacts header file on the next line:
#include "contacts.h"

int main (void)
{
    // Declare variables here:
       struct Name name = {"", "", ""};
       struct Address address = {0, "", 0, "", ""};
       struct Numbers numbers = {"","",""};
       char option ;
   // Display the title
       printf("Contact Management System\n");
       printf("-------------------------\n");

    // Contact Name Input:
       printf("Please enter the contact's first name: ");
       scanf("%30s", name.firstName);
       printf("Do you want to enter a middle initial(s)? (y or n): ");
       scanf(" %c",&option);
       if (option == 'y'){
	   printf("Please enter the contact's middle initial(s): ");
	   scanf("%6s", name.middleInitial);
       }
      
       printf("Please enter the contact's last name: ");
       scanf("%35s", name.lastName);
      
    // Contact Address Input:
	printf("Please enter the contact's street number: ");
	scanf("%d", &address.streetNumber);
	printf("Please enter the contact's street name: ");
	scanf("%40s", address.street);
	printf("Do you want to enter an apartment number? (y or n): ");
	scanf(" %c", &option);
	if (option == 'y'){
	     printf("Please enter the contact's apartment number: ");
	     scanf("%d", &address.apartmentNumber);
	}
	printf("Please enter the contact's postal code: ");
	scanf(" %[^\n]", address.postalCode);
	printf("Please enter the contact's city: ");
	scanf("%40s", address.city);

    // Contact Numbers Input:
	 printf("Do you want to enter a cell phone number? (y or n): ");
	  scanf(" %c", &option);
	if (option == 'Y'){
	     printf("Please enter the contact's cell phone number: ");
	     scanf("%20s", numbers.cell);
	}
	 printf("Do you want to enter a home phone number? (y or n): ");
	  scanf(" %c", &option);
	 if (option == 'Y'){
	     printf("Please enter the contact's home phone number: ");
	     scanf("%20s", numbers.home);
	 }
	 printf("Do you want to enter a business phone number? (y or n): ");
	  scanf(" %c", &option);
	if (option == 'Y'){
	     printf("Please enter the contact's business phone number: ");
	     scanf("%20s", numbers.business);
	}




    // Display Contact Summary Details
	 printf("\nContact Details");
	 printf("\n---------------");
	 printf("\nName Details");
	 printf("\nFirst name: %s", name.firstName);
	 printf("\nMiddle initial(s): %s",name.middleInitial);
	 printf("\nLast name: %s", name.lastName);

	  printf("\n\nAddress Details");
	  printf("\nStreet number: %d", address.streetNumber);
	  printf("\nStreet name: %s",address.street);
	  printf("\nApartment: %d",address.apartmentNumber);
	  printf("\nPostal code: %s",address.postalCode);
	  printf("\nCity: %s",address.city);

	  printf("\n\nPhone Numbers:");
	  printf("\nCell phone number: %s",numbers.cell);
	  printf("\nHome phone number: %s",numbers.home);
	  printf("\nBusiness phone number: %s",numbers.business);

    // Display Completion Message

	 printf("\n\nStructure test for Name, Address, and Numbers Done!\n");

    return 0;
}

/*  SAMPLE OUTPUT:

Contact Management System
-------------------------
Please enter the contact's first name: Tom
Do you want to enter a middle initial(s)? (y or n): y
Please enter the contact's middle initial(s): Wong
Please enter the contact's last name: Song
Please enter the contact's street number: 20
Please enter the contact's street name: Keele
Do you want to enter an appartment number? (y or n): y
Please enter the contact's appartment number: 40
Please enter the contact's postal code: A8A 4J4
Please enter the contact's city: Toronto
Do you want to enter a cell phone number? (y or n): Y
Please enter the contact's cell phone number: 905-111-6666
Do you want to enter a home phone number? (y or n): Y
Please enter the contact's home phone number: 705-222-7777
Do you want to enter a business phone number? (y or n): Y
Please enter the contact's business phone number: 416-333-8888
Contact Details
---------------
Name Details
First name: Tom
Middle initial(s): Wong
Last name: Song
Address Details
Street number: 20
Street name: Keele
Apartment: 40
Postal code: A8A 4J4
City: Toronto
Phone Numbers:
Cell phone number: 905-111-6666
Home phone number: 705-222-7777
Business phone number: 416-333-8888
Structure test for Name, Address, and Numbers Done!
*/
