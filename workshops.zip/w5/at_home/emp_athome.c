#include <stdio.h>
#define SIZE 4

struct Employee
{
	int id;
	int age;
	double salary;
};

int main(void)
{
	struct Employee emp[SIZE] = { { 0 } };
	int option = 0, a=0,  exit = 0, i=0,  j = 0, number = 0, position = 0;
	printf("---=== EMPLOYEE DATA ===---\n");

	// Declare a struct Employee array "emp" with SIZE elements
	// initialize all elements to zero

	do {
		
		printf("\n1. Display Employee Information\n");
		printf("2. Add Employee\n");
		printf("3. Update Employee Salary\n");
		printf("4. Remove Employee\n");
		printf("0. Exit\n\n");
		printf("Please select from the above options: ");

		// Read input to option variable
		scanf("%d", &option);
		printf("\n");

		switch (option) {
		case 0:
			printf("Exiting Employee Data Program. Good Bye!!!\n"); // Exit the program
			break;
		case 1:
			
			printf("EMP ID  EMP AGE EMP SALARY\n");
			printf("======  ======= ==========\n");

			for ( a = 0; a < SIZE && a >= 0; a++)
			{
				if (emp[a].id > 0) {
					printf("%6d%9d%11.2lf\n", emp[a].id, emp[a].age, emp[a].salary);
				}
			}
			
			break;
		case 2: 
				
			printf("Adding Employee\n");
			printf("===============");

			if (number < SIZE)
			{
				printf("\nEnter Employee ID: ");
				scanf("%d", &emp[number].id);
				if (emp[number].id > 0)
				{
					printf("Enter Employee Age: ");
					scanf("%d", &emp[number].age);
					printf("Enter Employee Salary: ");
					scanf("%lf", &emp[number].salary);
					number++;
				}
			}
			else
			{
				printf("\nERROR!!! Maximum Number of Employees Reached\n");
			}


			break;
		case 3:
			do {
				printf("Update Employee Salary\n");
				printf("======================\n");
				printf("Enter Employee ID: ");
				scanf("%d", &j);
				for (i = 0; i < SIZE; i++) {
					if (j == emp[i].id) {
						printf("The current salary is %.2lf\n", emp[i].salary);
						printf("Enter Employee New Salary: ");
						scanf("%lf", &emp[i].salary);

						exit = 1;
					}
				}

			 } while (exit != 1); break;

			break;
		case 4:

			do
			{
				printf("Remove Employee\n");
				printf("===============\n");
				printf("Enter Employee ID: ");
				scanf("%d", &j);
				for ( i = 0; i < SIZE - 1; i++)
				{
					if (j == emp[i].id) {
						position = i;
					}
				}

				while (position < SIZE)
				{
					if (position == SIZE - 1)
					{
						emp[position].id = 0;
						emp[position].age = 0;
						emp[position].salary = 0;
					}
					else
					{
						emp[position] = emp[position + 1];
					}
					position++;
				}
				number--;

				printf("Employee %d will be removed\n", j);

			} while (SIZE < i);

			break;

		default:

			printf("ERROR: Incorrect Option: Try Again\n");

		}

	} while (option != 0);

	return 0;
}
