// name-Shubham patel
// id - 115016172
// email- srpatel33@myseneca.ca
#include <stdio.h>
#define SIZE 2   //define number of employees SIZE to be 2
struct employee{
    int id;
    int age;
    double salary;
};

int main(void){
    struct employee emp[SIZE] = {{ 0 }};
    int option = 0 ;
    int i=0;
    printf("---=== EMPLOYEE DATA ===---\n");
	do{
	    printf("\n1. Display Employee Information\n");
	    printf("2. Add Employee\n");
	    printf("0. Exit\n");
	    printf("\nPlease select from the above options: ");
	    scanf("%d",&option);
	    printf("\n");
	      switch (option){
	      case 0:
		  printf("Exiting Employee Data Program. Good Bye!!!\n");
		 break;
	      case 1:
		  printf("EMP ID  EMP AGE EMP SALARY\n");
		  printf("======  ======= ==========\n");
			for (i = 0; i < SIZE; i++){
			    printf("%6d%9d%11.2lf\n", emp[i].id, emp[i].age, emp[i].salary);
			}
		  break;
		case 2:
		   printf("Adding Employee\n");
		   printf("===============");
		      if(i < SIZE){
				printf("\nEnter Employee ID: ");
				scanf("%d", &emp[i].id);
				printf("Enter Employee Age: ");
				scanf("%d", &emp[i].age);
				printf("Enter Employee Salary: ");
				scanf("%lf", &emp[i].salary);
				 i++;
		       }
			 else{
			      printf("\nERROR!!! Maximum Number of Employees Reached\n");
			  }
		     break;
		   default:
			printf("ERROR: Incorrect Option: Try Again\n");
		 }
	     
	       }while (option != 0);

    return 0;
}
