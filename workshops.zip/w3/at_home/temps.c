/* Shubham patel
   Student id- 115016172
   Email-srpatel33@myseneca.ca */


#include<stdio.h>
#define NUMS 4
int main(void){

	int high[4];
	int low[4];
	int i;
	int totalhigh=0,totallow=0,sum;
	float average;
	int highest,lowest,index,location;
	printf("---=== IPC Temperature Analyzer ===---\n");
	highest = -40;
	lowest = 40;
	for(i=0;i<NUMS;i++){
	     do{
			      printf("Enter the high value for day %d: ",i+1);
				   scanf("%d",&high[i]);
				  printf("\n");
				   printf("Enter the low value for day %d: ",i+1);
				   scanf("%d",&low[i]);
				  printf("\n");
				   if((high[i] < low[i])||(low[i]<-40 || low[i]>40)||(high[i]<-40 || high[i]>40)){
							 printf("Incorrect values, temperatures must be in the range -40 to 40, high must be greater than low.\n");
							 printf("\n");
				   }


		 }while((high[i] < low[i])||(low[i]<-40 || low[i]>40)||(high[i]<-40 || high[i]>40));
	      totalhigh += high[i];
	      totallow += low[i];
	      if(highest < high[i]){
	      highest = high[i];
	      index = i+1;
	      }
	      if(lowest > low[i]){
	      lowest = low[i];
	      location = i+1;
	      }
	     
	}
      sum = totalhigh + totallow;
      average= (double)sum/(2*NUMS);
      printf("The average (mean) temperature was: %.2f\n",average);
      printf("The highest temperature was %d, on day %d\n",highest,index);
      printf("The lowest temperature was %d, on day %d\n",lowest,location);
   return 0;
}

			
				  
				
				   
				   
				  
			       
	   
			 
				  
				
				   
				
				  
				 
