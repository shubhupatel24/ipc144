#include<stdio.h>
#define NUMS 3
int main(void){

	int high[3];
	int low[3];
	int i;
	int totalhigh=0,totallow=0,sum;
	float average;
	printf("---=== IPC Temperature Analyzer ===---\n");
	for(i=0;i<NUMS;i++){
		  do{ 
			      printf("Enter the high value for day %d: ",i+1);
				   scanf("%d",&high[i]);
				  printf("\n");
				   printf("Enter the low value for day %d: ",i+1);
				   scanf("%d",&low[i]);
				  printf("\n");
				   if((high[i] < low[i])||(low[i]<-40 || low[i]>40)||(high[i]<-40 || high[i]>40)){
							 printf("Incorrect values, temperatures must be in the range -40 to 40, high must be greater than low.\n");
							 printf("\n");
				   }
			    
			    
		    }while((high[i] < low[i])||(low[i]<-40 || low[i]>40)||(high[i]<-40 || high[i]>40));
	      totalhigh += high[i];
	      totallow += low[i];
	  
	}
      sum = totalhigh + totallow;
      average= (double)sum/(2*NUMS);
      printf("The average (mean) temperature was: %.2f\n",average);  
   return 0;
}





