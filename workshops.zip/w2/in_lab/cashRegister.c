#include<stdio.h>
int main (void)
{
	float amount;
	
	int n_Loonies;
	
	int n_Quarters;
	float reminder;
	float reminders;
	printf("Please enter the amount to be paid: $");
	scanf("%f",&amount);
	n_Loonies = amount/1;
	reminder = amount-n_Loonies;
	printf("Loonies required: %d, balance owing $%.2f\n",n_Loonies,reminder );

	n_Quarters =(reminder*100)/25;
	reminders = reminder - (n_Quarters *0.25);
	printf("Quarters required: %d, balance owing $%.2f\n",n_Quarters,reminders);











	return 0;
}
