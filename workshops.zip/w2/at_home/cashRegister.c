/* Shubham patel
   srpatel33@myseneca.ca
   student id-115016172 */

#include<stdio.h>
int main(void)
{
	double amount,GST,balance;
	int n_Loonies,n_Quarters,n_Dimes,n_Nickels,n_Pennies;
	float reminder,owing,owing1,owing2,owing3;
	
	printf("Please enter the amount to be paid: $");
	scanf("%lf",&amount);
	GST =(amount*0.13)+0.005;
	printf("GST: %.2lf\n",GST);
	balance=amount+GST;
	printf("Balance owing: $%.2lf\n",balance);
	n_Loonies = balance/1;
	reminder = balance-n_Loonies;
	printf("Loonies required: %d, balance owing $%.2lf\n",n_Loonies,reminder);
	n_Quarters = (reminder*100)/25;
	owing = reminder - (n_Quarters *0.25);
	printf("Quarters required: %d, balance owing $%.2f\n",n_Quarters,owing);
	n_Dimes = (owing*100)/10;
	owing1 = owing - (n_Dimes *0.10);
	printf("Dimes required: %d, balance owing $%.2f\n",n_Dimes,owing1);
	n_Nickels = (owing1*100)/5;
	owing2 = owing1 - (n_Nickels *0.05);
	printf("Nickels required: %d, balance owing $%.2f\n",n_Nickels,owing2);
	n_Pennies = (owing2*100)/1;
	owing3 = owing2 - (n_Pennies *0.01);
	printf("Pennies required: %d, balance owing $%.2f\n",n_Pennies,owing3);
	return 0;
}
