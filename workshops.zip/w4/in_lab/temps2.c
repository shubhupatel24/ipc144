
#include<stdio.h>
int main(void)
{

int n_days=0;
int j;
int high[10] = {0};
int low[10] = {0};

    printf("---=== IPC Temperature Calculator V2.0 ===---\n");
    printf("Please enter the number of days, between 3 and 10, inclusive: ");

    scanf("%d", &n_days);
	printf("\n");

       while (n_days < 3 || n_days > 10){

		printf("Invalid entry, please enter a number between 3 and 10, inclusive: ");
		scanf("%d", &n_days);
	}

    printf("\n");

	   for (j = 0; j < n_days; j++){

	      printf("Day %d - High: ", j + 1);
	      scanf("%d", &high[j]);
	      printf("Day %d - Low: ", j + 1);
	      scanf("%d", &low[j]);
	    }


   printf("\n");
   printf("Day  Hi  Low\n");

	for (j = 0; j < n_days; j++){
	   printf("%d    %d    %d\n", j + 1, high[j], low[j]);
	}

 return 0;

}














