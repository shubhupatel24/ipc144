/* Name-Shubham Patel
   ID - 115016172
  Email-srpatel33@myseneca.ca */

#include<stdio.h>
#define n_days 10
int main(void){
	int ndays = 0;
	int j;
	int totalhigh=0,totallow=0;
	int highest=0,lowest=0,index,location;
	int num = 0; 
	int exit = 0;
	double avg = 0;
	double temp=0;
	int high[n_days]= { 0 };
	int low[n_days] = { 0 };

	printf("---=== IPC Temperature Calculator V2.0 ===---\n");
	printf("Please enter the number of days, between 3 and %d, inclusive: ",n_days);
	scanf("%d", &ndays);

	while (ndays < 3 || ndays > 10){
		printf("\nInvalid entry, please enter a number between 3 and %d, inclusive: ",n_days);
		scanf("%d", &ndays);
	 }
	printf("\n");

	      for (j = 0; j < ndays; j++){
		printf("Day %d - High: ", j + 1);
		scanf("%d", &high[j]);
		printf("Day %d - Low: ", j + 1);
		scanf("%d", &low[j]);
	      }

	printf("\n");
	printf("Day  Hi  Low\n");

	for (j = 0; j < ndays; j++){
		printf("%d    %d    %d\n", j + 1, high[j], low[j]);
	
	      totalhigh += high[j];
	      totallow += low[j];
	      if(highest < high[j]){
	      highest = high[j];
	      index = j+1;
	      }
	      if(lowest > low[j]){
	      lowest = low[j];
	      location = j+1;
	      }
	}
      printf("\n");
      printf("The highest temperature was %d, on day %d\n",highest,index);
      printf("The lowest temperature was %d, on day %d\n",lowest,location);

	       printf("\nEnter a number between 1 and %d to see the average temperature for the entered number of days, enter a negative number to exit: ",ndays);
		  scanf("%d", &num);

		do{
		    if (num >= 1 && num <= 4){
			for (j = 0; j < num; j++){
				temp += high[j] + low[j];
			}

			avg = (temp / (num * 2));
			temp=0;
			printf("\nThe average temperature up to day %d is: %.2lf\n", num, avg);
			printf("\nEnter a number between 1 and %d to see the average temperature for the entered number of days, enter a negative number to exit: ",ndays);
			scanf("%d", &num);
		     }
		  else if(num < 0){
			printf("\nGoodbye!\n");
			exit = 1;
		  }
		   else{
			printf("\nInvalid entry, please enter a number between 1 and 4, inclusive: ");
			scanf("%d", &num);
		   }
		}while(exit == 0);
	    return 0;
}
