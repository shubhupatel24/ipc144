#include<stdio.h>
int main(void)
{
    printf("******************************\n** Welcome to C Programming **\n******************************\n");


return 0;
}
