#include <stdio.h>
int main(void)
{

   printf("** Welcome to C Programming **\n\t");



   return 0;
}
